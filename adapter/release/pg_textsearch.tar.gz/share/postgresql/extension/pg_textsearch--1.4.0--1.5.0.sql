-- Upgrade from 1.4.0 to 1.5.0

-- Verify the library is loaded. The version-equality check lives in
-- the main install file (pg_textsearch--<default_version>.sql); upgrade
-- scripts must accept any loaded version because they may run as
-- intermediate steps in a chain that ends at default_version, not at
-- the version named in this filename.
DO $$
BEGIN
    IF pg_catalog.current_setting('pg_textsearch.library_version', true)
       IS NULL THEN
        RAISE EXCEPTION
            'pg_textsearch library not loaded. '
            'Add pg_textsearch to shared_preload_libraries and restart.';
    END IF;
END $$;

COMMENT ON FUNCTION @extschema@.bm25_force_merge(text) IS
    'Run one-shot copy-on-write compaction into the fewest conservatively size-bounded segments; existing over-budget singletons remain uncombinable, and displaced pages enter deferred reclaim.';

-- PARALLEL RESTRICTED: opens the index relation, which may be a local
-- temporary index whose buffers a parallel worker cannot reach.
CREATE FUNCTION @extschema@.bm25_level_counts(idx regclass)
RETURNS int[]
AS 'MODULE_PATHNAME', 'tp_level_counts'
LANGUAGE C VOLATILE STRICT PARALLEL RESTRICTED;

CREATE FUNCTION @extschema@.bm25_compact(idx regclass)
RETURNS void
AS 'MODULE_PATHNAME', 'tp_compact_index'
LANGUAGE C VOLATILE STRICT;

COMMENT ON FUNCTION @extschema@.bm25_compact(regclass) IS
    'Run threshold compaction to completion, yielding per-index maintenance admission between passes. Published passes are not undone by ROLLBACK, so a cascade that errors partway leaves its earlier passes applied.';

CREATE FUNCTION @extschema@.bm25_compact_step(idx regclass)
RETURNS boolean
AS 'MODULE_PATHNAME', 'tp_compact_index_step'
LANGUAGE C VOLATILE STRICT;

COMMENT ON FUNCTION @extschema@.bm25_compact_step(regclass) IS
    'Run at most one compaction pass and report whether one ran, letting a caller spread a cascade over several transactions. A published pass is not undone by ROLLBACK.';

CREATE FUNCTION @extschema@.bm25_compact_step_if_current(
    index_oid oid, database_oid oid, tablespace_oid oid,
    relfilenumber oid, owner_oid oid)
RETURNS boolean
AS 'MODULE_PATHNAME', 'tp_compact_index_step_if_current'
LANGUAGE C VOLATILE STRICT;

CREATE FUNCTION @extschema@.bm25_background_target_is_current(
    index_oid oid, database_oid oid, tablespace_oid oid,
    relfilenumber oid, owner_oid oid)
RETURNS boolean
AS 'MODULE_PATHNAME', 'tp_background_target_is_current'
LANGUAGE C VOLATILE STRICT;

REVOKE ALL ON FUNCTION
    @extschema@.bm25_compact_step_if_current(oid, oid, oid, oid, oid)
    FROM PUBLIC;
REVOKE ALL ON FUNCTION
    @extschema@.bm25_background_target_is_current(oid, oid, oid, oid, oid)
    FROM PUBLIC;

-- VOLATILE because it runs the compaction planner against live
-- metapage state, and PARALLEL RESTRICTED to match bm25_level_counts.
CREATE FUNCTION @extschema@.bm25_needs_compaction(idx regclass)
RETURNS boolean
AS 'MODULE_PATHNAME', 'tp_needs_compaction'
LANGUAGE C VOLATILE STRICT PARALLEL RESTRICTED;

COMMENT ON FUNCTION @extschema@.bm25_needs_compaction(regclass) IS
    'Report whether bm25_compact_step would run a pass on this index. A level that holds segments_per_level segments but cannot be reduced -- every candidate group exceeds max_segment_size -- reports false, so this is safe as a retry condition.';

-- Session-local count of BM25 scoring passes.  Scan depth is invisible
-- in query results (Filter + Limit + backoff produce the exact top-k
-- either way), so this is the signal that a filtered top-k scan was
-- seeded from its own filter rather than another scan's (issue #435).
CREATE FUNCTION @extschema@.bm25_debug_scoring_passes(
    reset boolean DEFAULT false)
    RETURNS bigint
    AS 'MODULE_PATHNAME', 'tp_debug_scoring_passes'
    LANGUAGE C VOLATILE STRICT;

ALTER OPERATOR FAMILY @extschema@.text_bm25_ops USING bm25
    ADD OPERATOR 1 pg_catalog.@@ (text, pg_catalog.tsquery);
